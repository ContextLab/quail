from .load import load, load_example_data
from .egg import Egg
from .analysis import analyze
from .plot import plot
from .helpers import stack_eggs, crack_egg, recmat2egg, load_egg
from decode_speech import decode_speech
